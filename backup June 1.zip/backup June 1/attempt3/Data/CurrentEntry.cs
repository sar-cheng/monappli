﻿namespace attempt3.Data
{
    public static class CurrentEntry
    {
        public static bool IsNew { get; set; } = false;
        public static string Title { get; set; } = "new entry";
        public static string Time { get; set; } = Convert.ToString(DateTime.Now);
        public static string[] Content { get; set; } = default!;

        public static string Path { get; set; } = System.IO.Path.Combine(Directory.GetCurrentDirectory(), Title + ".txt");
    }
}
