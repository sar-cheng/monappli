﻿namespace attempt3.Windows;
/// <summary>
/// Interaction logic for ToDo.xaml
/// </summary>
public partial class ToDo : Window, INotifyPropertyChanged
{
    public ToDo()
    {
        InitializeComponent();

        AddPreviews(
            AppointmentType.ImportantToDo,
            AppointmentType.ToDo,
            AppointmentType.ImportantInProgress,
            AppointmentType.InProgress,
            AppointmentType.ImportantDone,
            AppointmentType.Done
            );
    }
    #region Access/mutate
    public ObservableCollection<AppointmentPreview> ToDoApps { get; set; } = new();
    public ObservableCollection<AppointmentPreview> InProgressApps { get; set; } = new();
    public ObservableCollection<AppointmentPreview> DoneApps { get; set; } = new();
    public enum AppointmentType
    {
        ImportantToDo,
        ToDo,
        ImportantInProgress,
        InProgress,
        ImportantDone,
        Done
    }
    public static string GetFolder(AppointmentType appointmentType)
        => appointmentType switch
        {
            AppointmentType.ImportantToDo => DataService.Paths.IToDo,
            AppointmentType.ToDo => DataService.Paths.ToDo,
            AppointmentType.ImportantInProgress => DataService.Paths.IInProgress,
            AppointmentType.InProgress => DataService.Paths.InProgress,
            AppointmentType.ImportantDone => DataService.Paths.IDone,
            AppointmentType.Done => DataService.Paths.Done,
            _ => throw new NotImplementedException()
        };
    public ObservableCollection<AppointmentPreview> GetCollection(AppointmentType appointmentType)
        => appointmentType switch
        {
            AppointmentType.ImportantToDo => ToDoApps,
            AppointmentType.ToDo => ToDoApps,
            AppointmentType.ImportantInProgress => InProgressApps,
            AppointmentType.InProgress => InProgressApps,
            AppointmentType.ImportantDone => DoneApps,
            AppointmentType.Done => DoneApps,
            _ => throw new NotImplementedException()
        };
    public static string GetDate(string file) => File.GetCreationTime(file).ToString("dd/MM/yy");
    public static string GetName(string filename) => filename.Remove(filename.Length - 4); //remove last 4 chars to remove .txt
    public static int GetStatusIndex (AppointmentType appointmentType)
        => appointmentType switch
        {
            AppointmentType.ImportantToDo => 0,
            AppointmentType.ToDo => 0,
            AppointmentType.ImportantInProgress => 1,
            AppointmentType.InProgress => 1,
            AppointmentType.ImportantDone => 2,
            AppointmentType.Done => 2,
            _ => throw new NotImplementedException()
        };
    public static bool GetImportance (AppointmentType appointmentType)
        => appointmentType switch
        {
            AppointmentType.ImportantToDo => true,
            AppointmentType.ToDo => false,
            AppointmentType.ImportantInProgress => true,
            AppointmentType.InProgress => false,
            AppointmentType.ImportantDone => true,
            AppointmentType.Done => false,
            _ => throw new NotImplementedException()
        };
    #endregion
    private void AddPreviews(params AppointmentType[] appointmentTypes) => appointmentTypes.ToList().ForEach(AddPreviews);
    private void AddPreviews(AppointmentType appointmentType)
    {
        string folder = GetFolder(appointmentType);
        ObservableCollection<AppointmentPreview> Collection = GetCollection(appointmentType);

        foreach (string file in Directory.EnumerateFiles(folder, "*.txt"))
        {
            string filename = System.IO.Path.GetFileName(file);
            string name = GetName(filename);
            string date = GetDate(file);
            bool isimportant = GetImportance(appointmentType);

            AppointmentPreview Preview = new() { AppointmentTitle = name, AppointmentDate = date };
            if (isimportant) Preview.Background = new SolidColorBrush(Colors.Bisque);
            else Preview.Background = new SolidColorBrush(Colors.White);
            Preview.MouseDoubleClick += (sender, e) =>
            {
                CurrentAppointment.IsNew = false;
                CurrentAppointment.Title = name;
                CurrentAppointment.Date = date;
                CurrentAppointment.Status = GetStatusIndex(appointmentType);
                CurrentAppointment.IsImportant = isimportant;
                CurrentAppointment.Content = File.ReadAllLines(file);

                Appointment appointment = new();
                appointment.Show();
                var current = GetWindow(this);
                current.Close();
            };
            Collection.Add(Preview);
        }
    }
    #region Controls Set-up
    private void NewToDo_Click(object sender, RoutedEventArgs e)
    {
        CurrentAppointment.IsNew = true;
        CurrentAppointment.Title = DataService.PreventDuplicateTitles("new appointment", DataService.DataType.Appointment);
        CurrentAppointment.Date = default!;
        CurrentAppointment.Status = 0;
        CurrentAppointment.Content = Array.Empty<string>();

        Appointment appointment = new();
        appointment.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    private void HomeButton_Click(object sender, RoutedEventArgs e)
            => DataService.ChangeWindow(this, new MainWindow());
    private void ToDoButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, this);
    private void TrackersButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MyTrackers());
    private void EntriesButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MyEntries());

    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null!)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    #endregion
}


