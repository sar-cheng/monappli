﻿namespace attempt3.Windows;
/// <summary>
/// Interaction logic for Appointment.xaml
/// </summary>
public partial class Appointment : Window, INotifyPropertyChanged
{
    public Appointment() => InitializeComponent();
    #region Access/mutate
    public string AppointmentTitle
    {
        get => _appointmenttitle;
        set
        {
            _appointmenttitle = value;
            OnPropertyChanged(nameof(AppointmentTitle));
        }
    }
    private string _appointmenttitle = CurrentAppointment.Title;
    public string AppointmentContent
    {
        get => _appointmentcontent;
        set
        {
            _appointmentcontent = value;
            OnPropertyChanged(nameof(_appointmentcontent));
        }
    }
    private string _appointmentcontent = string.Join(Environment.NewLine, CurrentAppointment.Content);
    public string AppointmentDate
    {
        get => _appointmentdate;
        set
        {
            _appointmentdate = value;
            OnPropertyChanged();
        }
    }
    private string _appointmentdate = CurrentAppointment.Date;
    public int AppointmentStatus
    {
        get => _appointmentstatus;
        set
        {
            _appointmentstatus = value;
            OnPropertyChanged();
        }
    }
    private int _appointmentstatus = CurrentAppointment.Status;
    public bool IsImportant
    {
        get => _isImportant;
        set
        {
            _isImportant = value;
            OnPropertyChanged();
        }
    }
    private bool _isImportant = CurrentAppointment.IsImportant;
    public UIElement Logo
    {
        get => _logo;
        set
        {
            _logo = value;
            OnPropertyChanged(nameof(Logo));
        }
    }
    private UIElement _logo = default!;
    private static string GetStatus(int statusindex) 
        => statusindex switch
        {
            0 => "TO DO",
            1 => "IN PROGRESS",
            2 => "DONE",
            _ => throw new NotImplementedException()
        };
    private static string GetPath(string status, bool isimportant, string appointmentname)
    {
        if (isimportant)
            return System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Appointments/" + status + "/IMPORTANT/" + appointmentname + ".txt");
        else
            return System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Appointments/" + status + "/" + appointmentname + ".txt");
    }
    private static void SetDate(string path, DateTime date)
    {
        try
        { File.SetCreationTime(path, date); }
        catch (ArgumentOutOfRangeException) 
        { File.SetCreationTime(path, DateTime.Now); }
    }
    private void SetImportance(string sourcefile, string status)
    {
        if (IsImportant)
        {
            string destionationfile = GetPath(status, true, AppointmentTitle);
            File.Move(sourcefile, destionationfile); //file already exists??
            CurrentAppointment.IsImportant = true;
        }
    }
    #endregion
    private void SaveContent(string path)
    {
        using (StreamWriter sw = File.CreateText(path))
        { sw.WriteLine(AppointmentContent); }
    }
    private void UpdateData()
    {
        using (StreamWriter sw = File.AppendText(DataService.Paths.AllAppointments))
        { sw.WriteLine(AppointmentTitle); }

        CurrentAppointment.Title = AppointmentTitle;
        CurrentAppointment.IsNew = false;
    }
    private void DeleteOldFile(string oldpath, string todelete, bool createnew) //get old path 
    {
        File.Delete(oldpath);

        //change list of appointment names
        var oldlines = File.ReadAllLines(DataService.Paths.AllAppointments);
        var newlines = oldlines.Select(x => x.Replace(todelete, AppointmentTitle)).ToArray();

        if (!createnew)
            newlines = oldlines.Where(line => !line.Contains(todelete)).ToArray();

        File.WriteAllLines(DataService.Paths.AllAppointments, newlines);
    }
    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (CurrentAppointment.IsNew) 
            AppointmentTitle = DataService.PreventDuplicateTitles(AppointmentTitle, DataService.DataType.Appointment);
        else //check if name has changed
        {
            if (AppointmentTitle != CurrentAppointment.Title) //if name changed
            {
                bool validtitle = DataService.TitleIsValid(AppointmentTitle);
                if (validtitle) AppointmentTitle = DataService.PreventDuplicateTitles(AppointmentTitle, DataService.DataType.Appointment);
                else
                {
                    MessageBox.Show("Title cannot contain special symbols");
                    goto End;
                } 
            }
            //no need to validate name if hasn't been changed
        }
            
        string oldstatus = GetStatus(CurrentAppointment.Status);
        string oldpath = GetPath(oldstatus, CurrentAppointment.IsImportant, CurrentAppointment.Title);
        string status = GetStatus(AppointmentStatus);
        string path = GetPath(status, false, AppointmentTitle); //will set importance later

        DeleteOldFile(oldpath, CurrentAppointment.Title, true);
        SaveContent(path);
        SetDate(path, Convert.ToDateTime(AppointmentDate));
        SetImportance(path, status);

        if (CurrentAppointment.IsNew) UpdateData();
        ToDoButton_Click(sender, e);

    End:;
    }
    #region Controls Set-up
    private void Important_Click(object sender, RoutedEventArgs e)
    {
        if (IsImportant)
        {
            AppointmentImportance.Background = new SolidColorBrush(Colors.Transparent);
            IsImportant = false;
        }
        else
        {
            AppointmentImportance.Background = new SolidColorBrush(Colors.AliceBlue);
            IsImportant = true;
        }
    }
    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        string path = GetPath(GetStatus(AppointmentStatus), IsImportant, AppointmentTitle);
        DeleteOldFile(path, AppointmentTitle, false);
    }
    private void Status_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        ComboBox? comboBox = sender as ComboBox;
        #pragma warning disable CS8602 // Dereference of a possibly null reference.
        AppointmentStatus = comboBox.SelectedIndex;
        #pragma warning restore CS8602 // Dereference of a possibly null reference.
    }
    private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
    {
        DatePicker? datePicker = sender as DatePicker;
        #pragma warning disable CS8602 // Dereference of a possibly null reference.
        #pragma warning disable CS8601 // Possible null reference assignment.
        AppointmentDate = datePicker.SelectedDate.ToString();
        #pragma warning restore CS8601 // Possible null reference assignment.
        #pragma warning restore CS8602 // Dereference of a possibly null reference.
    }
    private void HomeButton_Click(object sender, RoutedEventArgs e)
    {
        MainWindow Home = new();
        Home.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }

    private void ToDoButton_Click(object sender, RoutedEventArgs e)
    {
        Windows.ToDo toDo = new();
        toDo.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    private void TrackersButton_Click(object sender, RoutedEventArgs e)
    {
        Windows.MyTrackers myTrackers = new();
        myTrackers.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    private void EntriesButton_Click(object sender, RoutedEventArgs e)
    {
        Windows.MyEntries myEntries = new();
        myEntries.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null!)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    #endregion
}
