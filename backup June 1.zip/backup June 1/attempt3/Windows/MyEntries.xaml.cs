﻿namespace attempt3.Windows;
/// <summary>
/// Interaction logic for MyEntries.xaml
/// </summary>
public partial class MyEntries : Window, INotifyPropertyChanged
{
    public MyEntries()
    {
        InitializeComponent();

        //display all entries
        string[] EntryNames = File.ReadAllLines(DataService.Paths.AllEntries);
        foreach(string entryname in EntryNames)
        {
            try
            {
                string entrypath = System.IO.Path.Combine(Directory.GetCurrentDirectory(), entryname + ".txt");
                string entrydate = Convert.ToString(File.GetLastWriteTime(entrypath));
                Entries.Add(new EntryItem() { EntryTitle = entryname, EntryDate = entrydate});
            }
            catch (FileNotFoundException) { MessageBox.Show("fnf sarah??"); }
        }
        EntriesDisplay.ItemsSource = Entries;
    }
    public ObservableCollection<EntryItem> Entries { get; set; } = new();
    #region PropertyChanged

    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null!)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    #endregion
    private void HomeButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MainWindow());
    private void ToDoButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new ToDo());
    private void TrackersButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MyTrackers());
    private void EntriesButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MyEntries());
    private void NewEntry_Click(object sender, RoutedEventArgs e)
    {
        CurrentEntry.IsNew = true;
        CurrentEntry.Title = DataService.PreventDuplicateTitles("new entry", DataService.DataType.Entry);
        CurrentEntry.Time = Convert.ToString(DateTime.Now);
        CurrentEntry.Content = Array.Empty<string>();

        DataService.ChangeWindow(this, new Entry());
    }
    private void Entry_Click(object sender, RoutedEventArgs e)
    {
        CurrentEntry.IsNew = false;
        var senderBtn = sender as Button;
        CurrentEntry.Title = senderBtn.Content.ToString();
        CurrentEntry.Path = System.IO.Path.Combine(Directory.GetCurrentDirectory(), CurrentEntry.Title + ".txt");
        CurrentEntry.Time = Convert.ToString(File.GetLastWriteTime(CurrentEntry.Path)); 
        //last modified or created date?
        CurrentEntry.Content = File.ReadAllLines(CurrentEntry.Path);

        DataService.ChangeWindow(this, new Entry());
    }
}
public class EntryItem
{
    public EntryItem() { }
    public EntryItem(string entrytitle, string entrydate)
        => (EntryTitle, EntryDate) = (entrytitle, entrydate);
    public string EntryTitle { get; set; }
    public string EntryDate { get; set; }

}
