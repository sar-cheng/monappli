﻿namespace attempt3;
public static class DataService
{
    public enum DataType
    {
        Entry,
        Appointment,
        Habit
    }
    public static string GetPath(string path) => System.IO.Path.Combine(Directory.GetCurrentDirectory(), path);
    public static class Paths
    {
        public static string AllEntries = GetPath("!!ALL ENTRIES.txt");
        public static string AllAppointments = GetPath("Appointments/!!ALL APPOINTMENTS.txt");
        public static string AllHabits = GetPath("Habits/!!ALL HABITS.txt");

        public static string IToDo = GetPath("Appointments/TO DO/IMPORTANT");
        public static string IInProgress = GetPath("Appointments/IN PROGRESS/IMPORTANT");
        public static string IDone = GetPath("Appointments/DONE/IMPORTANT");
        public static string ToDo = GetPath("Appointments/TO DO");
        public static string InProgress = GetPath("Appointments/IN PROGRESS");
        public static string Done = GetPath("Appointments/DONE");

    }
    public static string PreventDuplicateTitles (string newname, DataType datatype)
    {
        var allentries
            = datatype switch
            {
                DataType.Entry => File.ReadAllLines(Paths.AllEntries),
                DataType.Appointment => File.ReadAllLines(Paths.AllAppointments),
                DataType.Habit => File.ReadAllLines(Paths.AllHabits),
                _ => throw new NotImplementedException(),
            };

        int i = 0;
        string setname = newname;
        while (allentries.Contains(newname))
        {
            i++;
            newname = string.Format("{0} ({1})", setname, i);
        }
        return newname;
    }
    public static bool TitleIsValid (string title)
    {
        bool isvalid = false;
        string allowedchar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ()";

        if (title.All(allowedchar.Contains)) 
            isvalid = true;
        //fix msg box pop ups -> references
        return isvalid;
    }
    public static void ChangeWindow(Window oldWindow, Window newWindow) 
    {
        if (oldWindow != newWindow)
        {
            newWindow.Top = oldWindow.Top;
            newWindow.Left = oldWindow.Left;
            newWindow.Show();
            oldWindow.Close();
        }
    }
}
