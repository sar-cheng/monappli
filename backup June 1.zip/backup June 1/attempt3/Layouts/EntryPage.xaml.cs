﻿namespace attempt3.Layouts;
/// <summary>
/// Interaction logic for EntryPage.xaml
/// </summary>
public partial class EntryPage : UserControl, INotifyPropertyChanged
{
    public EntryPage()
    {
        InitializeComponent();
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null!)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    
    public string EntryTitle
    {
        get => _entryTitle;
        set
        {
            _entryTitle = value;
            OnPropertyChanged(nameof(EntryTitle));

        }
    }
    private string _entryTitle = CurrentEntry.Title; 
    public string EntryTime
    {
        get => _entrytime;
        set
        {
            _entrytime = value;
        }
    }
    private string _entrytime = CurrentEntry.Time;  
    public string EntryContent
    {
        get => _entrycontent;
        set
        {
            _entrycontent = value;
            OnPropertyChanged(nameof(_entrycontent));
        }
    }
    private string _entrycontent = string.Join(Environment.NewLine, CurrentEntry.Content);  

    public bool CanSave { get; set; } = false;
    private void Save_Click(object sender, RoutedEventArgs e)
    {
        EntryTitle = DataService.PreventDuplicateTitles(EntryTitle, DataService.DataType.Entry);
        bool CanSave = DataService.TitleIsValid(EntryTitle);
        string filename = EntryTitle + ".txt";
        string filepath = System.IO.Path.Combine(Directory.GetCurrentDirectory(), filename);

        if (CanSave)
        {
            //search for duplicate names (when entry name is edited)

            DeleteEntry(CurrentEntry.Title, true); //deletes old copy to be replaced with new

            using StreamWriter sw = File.CreateText(filepath);
            sw.WriteLine(EntryContent);
            MessageBox.Show("Entry saved");

            if (CurrentEntry.IsNew)
            {
                using StreamWriter sw2 = File.AppendText(DataService.Paths.AllEntries);
                sw2.WriteLine(EntryTitle);
            }
            CurrentEntry.Title = EntryTitle;
        }
        else MessageBox.Show("Title cannot contain special symbols");
    }
    private void DeleteEntry(string todelete, bool createnew)
    {
        string filepath = System.IO.Path.Combine(Directory.GetCurrentDirectory(), todelete + ".txt");
        File.Delete(filepath);

        var oldlines = File.ReadAllLines(DataService.Paths.AllEntries);
        var newlines = oldlines.Select(x => x.Replace(todelete, EntryTitle)).ToArray();

        if (!createnew)
            newlines = oldlines.Where(line => !line.Contains(todelete)).ToArray();

        File.WriteAllLines(DataService.Paths.AllEntries, newlines);
    }
    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        DeleteEntry(CurrentEntry.Title, false);

        Windows.MyEntries myentries = new();
        myentries.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    private void HomeButton_Click(object sender, RoutedEventArgs e)
    {
        MainWindow Home = new();
        Home.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    private void ToDoButton_Click(object sender, RoutedEventArgs e)
    {
        Windows.ToDo toDo = new();
        toDo.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    private void TrackersButton_Click(object sender, RoutedEventArgs e)
    {
        Windows.MyTrackers myTrackers = new();
        myTrackers.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }
    private void EntriesButton_Click(object sender, RoutedEventArgs e)
    {
        Windows.MyEntries myEntries = new();
        myEntries.Show();
        var current = Window.GetWindow(this);
        current.Close();
    }

}
