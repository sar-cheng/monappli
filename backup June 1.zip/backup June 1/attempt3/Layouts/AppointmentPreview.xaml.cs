﻿namespace attempt3.Layouts;

/// <summary>
/// Interaction logic for AppointmentCard.xaml
/// </summary>
public partial class AppointmentPreview : UserControl, INotifyPropertyChanged
{
    public AppointmentPreview()
    {
        InitializeComponent();
        DataContext = this;
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null!)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    public string AppointmentTitle
    {
        get => _appointmentTitle;
        set
        {
            _appointmentTitle = value;
            OnPropertyChanged(nameof(AppointmentTitle));
        }
    }
    private string _appointmentTitle = default!;
    public string AppointmentDate
    {
        get => _appointmentDate;
        set
        {
            _appointmentDate = value;
            OnPropertyChanged();
        }
    }
    private string _appointmentDate = default!;
}

