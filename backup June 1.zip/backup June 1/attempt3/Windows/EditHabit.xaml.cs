﻿namespace attempt3.Windows
{
    /// <summary>
    /// Interaction logic for EditHabit.xaml
    /// </summary>
    public partial class EditHabit : Window
    {
        public EditHabit()
        {
            InitializeComponent();
        }

        private async void Confirm_Click(object sender, RoutedEventArgs e)
        {
            //name too long
            while (!DataService.TitleIsValid(NewNameBox.Text))

            CurrentHabit.Name = NewNameBox.Text;
            CurrentHabit.NameLeftUnchanged = false;
            Close();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            CurrentHabit.NameLeftUnchanged = true;
            Close();
        }
    }
}
