﻿namespace attempt3;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
    private void HomeButton_Click(object sender, RoutedEventArgs e)
        => throw new NotImplementedException();
    private void ToDoButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new Windows.ToDo());
    private void TrackersButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new Windows.MyTrackers());
    private void EntriesButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new Windows.MyEntries());
}

