﻿namespace attempt3.Layouts;

/// <summary>
/// Interaction logic for QuickEntry.xaml
/// </summary>
public partial class QuickEntry : UserControl, INotifyPropertyChanged
{
    public QuickEntry()
    {
        InitializeComponent();
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null!)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    private string _entrycontent = string.Empty;
    public string EntryContent
    {
        get => _entrycontent;  
        set
        {
            _entrycontent = value; 
            OnPropertyChanged();
        }
    }

}

