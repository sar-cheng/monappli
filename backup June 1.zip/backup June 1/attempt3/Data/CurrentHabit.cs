﻿namespace attempt3.Data
{
    public static class CurrentHabit
    {
        public static string Name { get; set; } = string.Empty;
        public static bool AreDatesLoaded { get; set; } = false;
        public static bool NameLeftUnchanged { get; set; } = false;
    }
}
