﻿namespace attempt3.Data
{
    public static class CurrentAppointment
    {
        public static bool IsNew { get; set; } = false;
        public static string Title { get; set; } = "new appointment";
        public static string Date { get; set; } = DateTime.Now.ToString("dd/MM/yy");
        public static int Status { get; set; } = 0;
        public static bool IsImportant { get; set; } = false;
        public static string[] Content { get; set; } = default!;

    }
}
