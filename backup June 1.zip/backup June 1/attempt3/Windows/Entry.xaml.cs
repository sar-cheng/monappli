﻿namespace attempt3.Windows;
/// <summary>
/// Interaction logic for NewEntry.xaml
/// </summary>
public partial class Entry : Window, INotifyPropertyChanged
{
    public Entry() => InitializeComponent();
    #region Access/mutate
    public event PropertyChangedEventHandler? PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null!)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    public string EntryTitle
    {
        get => _entryTitle;
        set
        {
            _entryTitle = value;
            OnPropertyChanged(nameof(EntryTitle));

        }
    }
    private string _entryTitle = CurrentEntry.Title;
    public string EntryTime
    {
        get => _entrytime;
        set
        {
            _entrytime = value;
        }
    }
    private string _entrytime = CurrentEntry.Time;
    public string EntryContent
    {
        get => _entrycontent;
        set
        {
            _entrycontent = value;
            OnPropertyChanged(nameof(_entrycontent));
        }
    }
    private string _entrycontent = string.Join(Environment.NewLine, CurrentEntry.Content);
    #endregion
    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (CurrentEntry.IsNew)
            EntryTitle = DataService.PreventDuplicateTitles(EntryTitle, DataService.DataType.Entry);
        else //check if name has changed
        {
            if (EntryTitle != CurrentEntry.Title) //if name changed
            {
                bool validtitle = DataService.TitleIsValid(EntryTitle);
                if (validtitle) EntryTitle = DataService.PreventDuplicateTitles(EntryTitle, DataService.DataType.Entry);
                else goto End;
            }
            //no need to validate name if hasn't been changed
        }
   
        string filename = EntryTitle + ".txt";
        string filepath = DataService.GetPath(filename);

        DeleteOldEntry(CurrentEntry.Title, true); //deletes old copy to be replaced with new
        SaveContent(filepath);

        if (CurrentEntry.IsNew) UpdateData();
        EntriesButton_Click(sender, e); //go back to home page

    End:;
    }
    private void SaveContent(string path)
    {
        using (StreamWriter sw = File.CreateText(path))
        { sw.WriteLine(EntryContent); }
    }
    private void UpdateData()
    {
        using StreamWriter sw2 = File.AppendText(DataService.Paths.AllEntries);
        sw2.WriteLine(EntryTitle);

        CurrentEntry.Title = EntryTitle;
        CurrentEntry.IsNew = false;
    }
    private void DeleteOldEntry(string todelete, bool createnew)
    {
        string filepath = DataService.GetPath(todelete + ".txt");
        File.Delete(filepath);

        var oldlines = File.ReadAllLines(DataService.Paths.AllEntries);
        var newlines = oldlines.Select(x => x.Replace(todelete, EntryTitle)).ToArray();

        if (!createnew)
            newlines = oldlines.Where(line => !line.Contains(todelete)).ToArray();

        File.WriteAllLines(DataService.Paths.AllEntries, newlines);
    }
    #region Controls Set-up
    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        DeleteOldEntry(CurrentEntry.Title, false);
        DataService.ChangeWindow(this, new MyEntries());
    }
    private void HomeButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MainWindow());
    private void ToDoButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new ToDo());
    private void TrackersButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MyTrackers());
    private void EntriesButton_Click(object sender, RoutedEventArgs e)
        => DataService.ChangeWindow(this, new MyEntries());
    #endregion
}

